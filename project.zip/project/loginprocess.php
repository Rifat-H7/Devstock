<?php
if(session_status()>=0){
    if(isset($_SESSION["email"])){
        header("refresh: 0.5; url=home.php");
    }
}
if(isset($_POST["submit"])){
    $email=$_POST["email"];
    $pass=$_POST["pass"];

    $con=mysqli_connect('localhost', 'root', '', 'dbdevstock');
    $sql="SELECT *FROM Account WHERE email='$email' and password='$pass' and User='Customer'";
    $sql1="SELECT *FROM Account WHERE email='$email' and password='$pass' and User='Developer'";
    $sql2="SELECT *FROM Account WHERE email='$email' and password='$pass' and User='Admin'";

    $result=mysqli_query($con, $sql);
    $result1=mysqli_query($con, $sql1);
    $row=mysqli_fetch_array($result, MYSQLI_ASSOC);
    $count=mysqli_num_rows($result);
    $row1=mysqli_fetch_array($result1, MYSQLI_ASSOC);
    $count1=mysqli_num_rows($result1);
    $result2=mysqli_query($con, $sql2);
    $row2=mysqli_fetch_array($result2, MYSQLI_ASSOC);
    $count2=mysqli_num_rows($result2);

    if($count==1){
        session_start();
        $_SESSION["email"]=$email;

        header("refresh: 0.5;url=cushome.php");
        exit();
    }
    elseif($count1==1 ){
        session_start();
        $_SESSION["email"]=$email;

        header("refresh: 0.5;url=devhome.php");
        exit();
    }
    elseif($count2==1){
        session_start();
        $_SESSION["email"]=$email;
        header("refresh: 0.5;url=admin.php");
        exit();
    }
    else{
        echo "user not found";
        header("refresh: 2; url=login.php");
        exit();
    }
}
?>
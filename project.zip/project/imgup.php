
<!DOCTYPE html>
<html lang="en">

<head>
    <link rel="stylesheet" href="imgup.css">
    <title>Document</title>
</head>

<body>

    <div class="container">
        <div class="text">
            <form action="imgupprocess.php" method="post" enctype="multipart/form-data">
                <span style="--i:1">Upload an image</span>
                <br>
                <span style="--i:2">Price ($): <input type="text" name="pr" required></span>
                <br>
                <span style="--i:3">Select Image File:</span>
                <br>
                <input type="file" name="image">
                <input type="submit" name="submit" value="Upload">

            </form>
        </div>
    </div>


</body>

</html>
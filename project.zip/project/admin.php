<?php
$con = mysqli_connect('localhost', 'root', '', 'dbdevstock');
$result = mysqli_query($con, "SELECT * FROM Account Where User!='Admin'");
?>
<!DOCTYPE html>
<html lang="en">

<head>
	<title>Admin</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!--===============================================================================================-->
	<link rel="icon" type="image/png" href="admincss/images/icons/favicon.ico" />
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="admincss/vendor/bootstrap/css/bootstrap.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="admincss/fonts/font-awesome-4.7.0/css/font-awesome.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="admincss/vendor/animate/animate.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="admincss/vendor/select2/select2.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="admincss/vendor/perfect-scrollbar/perfect-scrollbar.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="admincss/css/util.css">
	<link rel="stylesheet" type="text/css" href="admincss/css/main.css">
	<link rel="stylesheet" href="adcss.css">
	<!--===============================================================================================-->
</head>

<body>
<div id="main-header">
        <div class="container">
        <h1 class="h1">Admin Homepage</h1><b>
        </div>
    </div>
	<div class="limiter">
		<div class="container-table100">
			<div class="wrap-table100">
				<div class="table100 ver1 m-b-110">
					<div class="table100-head">
						<table>
							<thead>
								<tr class="row100 head">
									<th class="cell100 column1">Name</th>
									<th class="cell100 column2">Email</th>
									<th class="cell100 column3">Phone Number</th>
									<th class="cell100 column4">Address</th>
									<th class="cell100 column5">Password</th>
									<th class="cell100 column6">User</th>
									<th class="cell100 column7">Action</th>
								</tr>
							</thead>
						</table>
					</div>

					<div class="table100-body js-pscroll">
						<table>
							<tbody>
								<?php
								$i = 0;
								while ($row = mysqli_fetch_array($result)) {
								?>
									<tr class="row100 body">
										<td class="cell100 column1"><?php echo $row["Name"]; ?></td>
										<td class="cell100 column2"><?php echo $row["Email"]; ?></td>
										<td class="cell100 column3"><?php echo $row["Phone"]; ?></td>
										<td class="cell100 column4"><?php echo $row["Address"]; ?></td>
										<td class="cell100 column5"><?php echo $row["Password"]; ?></td>
										<td class="cell100 column6"><?php echo $row["User"]; ?></td>
										<td class="cell100 column7"><a href="deleteprocess.php?Email=<?php echo $row["Email"]; ?>">Delete</a></td>
									</tr>
								<?php
									$i++;
								}
								?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>


	<!--===============================================================================================-->
	<script src="admincss/vendor/jquery/jquery-3.2.1.min.js"></script>
	<!--===============================================================================================-->
	<script src="admincss/vendor/bootstrap/js/popper.js"></script>
	<script src="admincss/vendor/bootstrap/js/bootstrap.min.js"></script>
	<!--===============================================================================================-->
	<script src="admincss/vendor/select2/select2.min.js"></script>
	<!--===============================================================================================-->
	<script src="admincss/vendor/perfect-scrollbar/perfect-scrollbar.min.js"></script>
	<script>
		$('.js-pscroll').each(function() {
			var ps = new PerfectScrollbar(this);

			$(window).on('resize', function() {
				ps.update();
			})
		});
	</script>
	<!--===============================================================================================-->
	<script src="admincss/js/main.js"></script>

</body>

</html>
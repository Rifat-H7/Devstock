<?php
include 'filedownprocess.php';
session_start();
$price=$_SESSION['Price'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Payment Gateway</title>
</head>
<body>
    <p>pay</p>
    <form method="POST">
         <input type="text" name="phone" placeholder="Enter...">
         <input type="password" name="pin" placeholder="pin...">
         <a href="payment.php?file_id=<?php echo $file['id'] ?>">Pay & Download</a>
    </form>
</body>
</html>


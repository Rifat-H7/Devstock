
<?php
error_reporting(0);
session_start();
$email = $_SESSION['email']; 

$conn = mysqli_connect('localhost', 'root', '', 'dbdevstock');
$sql = "SELECT * FROM files WHERE email='$email'";
$result = mysqli_query($conn, $sql);

$files = mysqli_fetch_all($result, MYSQLI_ASSOC);

if (isset($_POST['save'])) { 
    
    $filename = $_FILES['myfile']['name'];
    $destination = 'uploads/' . $filename;

    $extension = pathinfo($filename, PATHINFO_EXTENSION);

    $file = $_FILES['myfile']['tmp_name'];
    $size = $_FILES['myfile']['size'];

    if (!in_array($extension, ['zip', 'pdf', 'docx' , 'txt'])) {
        echo "You file extension must be .zip, .pdf or .docx";
    } elseif ($_FILES['myfile']['size'] > 1000000) { 
        echo "File too large!";
    } else {
        if (move_uploaded_file($file, $destination)) {
            $price=$_POST["pr"];
            $des=$_POST["des"];
            $sql = "INSERT INTO files (name, size, Description, downloads, Price, Email) VALUES ('$filename', $size, '$des',0,'$price','$email') ";
            if (mysqli_query($conn, $sql)) {
                echo "File uploaded successfully";
            }
        } else {
            echo "Failed to upload file.";
        }
    }
}
if (isset($_GET['file_id'])) {
  $id = $_GET['file_id'];

  $sql = "SELECT * FROM files WHERE Email='$email'";
  $result = mysqli_query($conn, $sql);

  $file = mysqli_fetch_assoc($result);
  $filepath = 'uploads/' . $file['name'];

  if (file_exists($filepath)) {
      header('Content-Description: File Transfer');
      header('Content-Type: application/octet-stream');
      header('Content-Disposition: attachment; filename=' . basename($filepath));
      header('Expires: 0');
      header('Cache-Control: must-revalidate');
      header('Pragma: public');
      header('Content-Length: ' . filesize('uploads/' . $file['name']));
      readfile('uploads/' . $file['name']);

      $newCount = $file['downloads'] + 1;
      $updateQuery = "UPDATE files SET downloads=$newCount WHERE id=$id";
      mysqli_query($conn, $updateQuery);
      exit;
  }

}
<?php
session_start();

error_reporting(0);
$con = mysqli_connect('localhost', 'root', '', 'dbdevstock');

if ($con->connect_error) {
    die("Connection failed: " . $db->connect_error);
}
?>
<?php
$status = $statusMsg = '';
if (isset($_POST["submit"])) {
    $status = 'error';
    if (!empty($_FILES["image"]["name"])) {
        $email = $_SESSION['email'];

        $fileName = basename($_FILES["image"]["name"]);
        $fileType = pathinfo($fileName, PATHINFO_EXTENSION);

        $allowTypes = array('jpg', 'PNG', 'jpeg', 'gif');
        if (in_array($fileType, $allowTypes)) {
            $image = $_FILES['image']['tmp_name'];
            $imgContent = addslashes(file_get_contents($image));
            $price = $_POST["pr"];
            $insert = $con->query("INSERT into uploads (name, image, Price, Email) VALUES ('$fileName','$imgContent', $price, '$email')");

            if ($insert) {
                $status = 'success';
                $statusMsg = "File uploaded successfully.";
            } else {
                $statusMsg = "File upload failed, please try again.";
            }
        } else {
            $statusMsg = 'Sorry, only JPG, JPEG, PNG, & GIF files are allowed to upload.';
        }
    } else {
        $statusMsg = 'Please select an image file to upload.';
    }
}

echo $statusMsg;
?>
<?php


$result = $con->query("SELECT image, Price FROM uploads WHERE Email='$email' ORDER BY id DESC");
?>

<?php if ($result->num_rows > 0) { ?>
    <div>
        <?php while ($row = $result->fetch_assoc()) { ?>
            <img src="data:image/jpg;charset=utf8;base64,<?php echo base64_encode($row['image']); ?>" />
            <?php echo $row['Price'];?>
        <?php } ?>
    </div>
<?php } else { ?>
    <p>Image(s) not found...</p>
<?php } ?>
<?php

if (isset($_POST["submit"])){
    $name = $_POST["name"];
    $email = filter_var($_POST["email"],FILTER_SANITIZE_EMAIL);
    $pnum = $_POST["pnum"];
    $address = $_POST["address"];
    $user=$_POST["usr"];
    if (filter_var($email,FILTER_SANITIZE_EMAIL) && $user=="dev"){
        $pass = $_POST["pass"];
        $con = mysqli_connect('localhost', 'root', '', 'dbdevstock');
        $sql = "INSERT INTO Account (Name, Email, Phone, Address, Password, User)
        VALUES('$name', '$email', '$pnum', '$address', '$pass' , 'Developer')";
        if (mysqli_query($con, $sql)){
            session_start();
            $_SESSION["name"] = $_POST["name"];
            $_SESSION["email"] = $_POST["email"];
            $_SESSION["pnum"] = $_POST["pnum"];
            $_SESSION["address"] = $_POST["address"];
            $_SESSION["user"] = $_POST["usr"];
            echo "reg complete<br>";
            echo "redirecting to";
            header("refresh: 1; url = devhome.php");
        }
    }
    elseif(filter_var($email,FILTER_SANITIZE_EMAIL) && $user=="cus"){
        $pass = $_POST["pass"];
        $con = mysqli_connect('localhost', 'root', '', 'dbdevstock');
        $sql = "INSERT INTO Account (Name, Email, Phone, Address, Password, User)
        VALUES('$name', '$email', '$pnum', '$address', '$pass' , 'Customer')";
        if (mysqli_query($con, $sql)){
            session_start();
            $_SESSION["name"] = $_POST["name"];
            $_SESSION["email"] = $_POST["email"];
            $_SESSION["pnum"] = $_POST["pnum"];
            $_SESSION["address"] = $_POST["address"];
            $_SESSION["user"] = $_POST["usr"];
            echo "reg complete<br>";
            echo "redirecting to";
            header("refresh: 1; url = cushome.php");
        }
    }
else{
        echo "incorrect email";
        header("url = signup.php");
    }
}
else{
    if(session_status() == PHP_SESSION_NONE){
        header("location:signup.php");
    }
}

?>
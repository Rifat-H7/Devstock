<?php
$con=mysqli_connect('localhost', 'root', '', 'dbdevstock');
$sql = "DELETE FROM Account WHERE Email='" . $_GET["Email"] . "'";
if (mysqli_query($con, $sql)) {
    echo "Record deleted successfully";
} else {
    echo "Error deleting record: " . mysqli_error($con);
}
mysqli_close($con);
?>
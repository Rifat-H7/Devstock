<html>
<head>
    <style>
        body{
   font-size:20px;
            color: white;
            background-size: cover;
        }
         .box{ width: 900px;
       float:right;
       border:1px solid none;}
       .box ul li{
           width: 120px;
           float:left;
           margin: 10px auto;
           text-align: center;
       }
 .mainmenu
.mainmenu a
.mainmenu a:hover
.mainmenu img{
position: fixed;
z-index: -1;
top:0px; left:0px; width:100%; height: 100vh;
opacity: 0.9;
/*object-fit:cover;*/
transition: all ease 0.5s;
}
   .wd{
           width: 355px;
           height: 539px;
           background-color: black;
           opacity: 0.8;
           padding: 55px;
       }
       .wd h1{
           text-align: center;
           text-transform: uppercase;
           font-weight: 300px;
       }
       .wd h4{
           text-align: justify;
           color:darkgray;
           font-weight: 100px;
       }
       .wd h2{
           text-align: center;
           text-transform: uppercase;
           font-weight: normal;
           margin: 40px auto;
       }
       .opt form , input[type="button"]{
           background-color: black;
           color:white;
         /* padding:10px;*/
           margin:-14px auto;
           padding-left: 50px;
           padding-right: 50px;
           text-align: center;
           font-size: 16px;
       }
       
     form, input[type="button"] {
       animation: glowing 300ms infinite;
       font-weight: 500%;
      }
      @keyframes glowing {
 0% {
   background-color: red;
 }
 50% {
   background-color: orange;
 }
 100% {
   background-color: blue;
 }
}
   </style>
</head>
<body>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script>
$(function(){
var image = $(".mainmenu").find('img').attr('src');
$(".mainmenu a").mouseover(function(){
var newimg = $(this).attr('data-image');
$(this).parent().find('img').attr("src", newimg);
});
});
</script>
   <div class="box">
<div class="mainmenu">
<img src="23.png" height="650px" width="900px">

</div>
   </div>
   <div class="wd">
<h1> Welcome to Devstock</h1>
<h4> <i>    &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp       Post content and get paid</i></h4><br>
<a href="signup.php">Create an account</a><br>
<a href="login.php">Login</a>


</form>
</div>
</body>
</html>
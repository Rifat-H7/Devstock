<?php
include 'fileupprocess.php';
?>
<!DOCTYPE html>
<html>

<head>
  <link rel="stylesheet" href="imgup.css">
  <title>PHP File Upload</title>
</head>

<body>
  <?php
  if (isset($_SESSION['message']) && $_SESSION['message']) {
    echo ($_SESSION['message']);
    unset($_SESSION['message']);
  }
  ?>
  <form action="fileup.php" method="post" enctype="multipart/form-data">
    <div class="container">
      <div class="text">
        <span style="--i:1">choose your file to upload</span><br>
        <span style="--i:2">Upload a File (zip, pdf, docx, txt)</span><br>
        <span style="--i:3">Write description: <input type="text" name="des"><br></span>
        <span style="--i:4"> Price ($): <input type="text" name="pr"><br></span>
        <span style="--i:5">
          <input type="file" name="myfile">
          <button type="submit" name="save">upload</button>
        </span>

      </div>
    </div>
  </form>
</body>

</html>
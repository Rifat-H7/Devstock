<?php
include 'filedownprocess.php';
session_start();
$email = $_SESSION['email'];
$con=mysqli_connect('localhost', 'root', '', 'dbdevstock');
$result = mysqli_query($con,"SELECT * FROM account Where Email='$email'");
$sql="SELECT *FROM account WHERE email='$email'";
if(isset($_POST['re_password']))
{
$old_pass=$_POST['password'];
$new_pass=$_POST['new_pass'];
$re_pass=$_POST['re_pass'];
$chg_pwd=mysqli_query($con,"SELECT * FROM account Where Email='$email'");
$chg_pwd1=mysqli_fetch_array($chg_pwd);
$data_pwd=$chg_pwd1['Password'];
if($data_pwd==$old_pass){
if($new_pass==$re_pass){
    $update_pwd=mysqli_query($con,"UPDATE account SET Password='$new_pass' where Email='$email'");
    echo "<script>alert('Update Sucessfully'); window.location='devhome.php'</script>";
}
else{
    echo "<script>alert('Your new and Retype Password is not match'); window.location='devhome.php'</script>";
}
}
else{
    echo "<script>alert('Your old password is wrong'); window.location='devhome.php'</script>";
}}
?>
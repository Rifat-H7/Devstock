<?php
include 'fileupprocess.php'; ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Developer</title>
    <link rel="stylesheet" href="devcss.css">
</head>

<body>
<a class="a" href="changepass.php">My Profile</a>
    <div>
        <div class="container">
            <h2 class="title">
                <span class="title-word title-word-1">Welcome</span>
                <span class="title-word title-word-2">to</span>
                <span class="title-word title-word-3">Developer</span>
                <span class="title-word title-word-4">Homepage</span>
            </h2>
        </div>
        <
        <br>
        <div class="center">
            <span class="p">Uploaded</span> <span class="p1"> Contents</span>
        </div>
        <?php

        $con = mysqli_connect('localhost', 'root', '', 'dbdevstock');

        if ($con->connect_error) {
            die("Connection failed: " . $db->connect_error);
        }


        $result = $con->query("SELECT image FROM uploads WHERE Email='$email' ORDER BY id DESC");
        ?>

        <?php if ($result->num_rows > 0) { ?>
            <div class="wrapper">

                <?php while ($row = $result->fetch_assoc()) { ?>
                    <img class="box" width="400" height="300" src="data:image/jpg;charset=utf8;base64,<?php echo base64_encode($row['image']); ?>" />
                <?php } ?>

            </div>

        <?php } else { ?>
            <p class="status error">Image(s) not found...</p>
        <?php } ?>

        <div class="center">
        <span class="p">Uploaded</span> <span class="p1"> Files</span>
        </div>
        <table class="styled-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>FileName</th>
                    <th>Size</th>
                    <th>Downloads</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($files as $file) : ?>
                    <tr class="active-row">
                        <td><?php echo $file['id']; ?></td>
                        <td><?php echo $file['name']; ?></td>
                        <td><?php echo floor($file['size'] / 1000) . ' KB'; ?></td>
                        <td><?php echo $file['downloads']; ?></td>

                    </tr>
                <?php endforeach; ?>

            </tbody>
            </thead>

        </table>
        <?php

        if (isset($_GET['file_id'])) {
            $id = $_GET['file_id'];


            $sql = "SELECT * FROM files WHERE Email='$email'";
            $result = mysqli_query($conn, $sql);

            $file = mysqli_fetch_assoc($result);
            $filepath = 'uploads/' . $file['name'];

            if (file_exists($filepath)) {
                header('Content-Description: File Transfer');
                header('Content-Type: application/octet-stream');
                header('Content-Disposition: attachment; filename=' . basename($filepath));
                header('Expires: 0');
                header('Cache-Control: must-revalidate');
                header('Pragma: public');
                header('Content-Length: ' . filesize('uploads/' . $file['name']));
                readfile('uploads/' . $file['name']);


                $newCount = $file['downloads'] + 1;
                $updateQuery = "UPDATE files SET downloads=$newCount WHERE id=$id";
                mysqli_query($conn, $updateQuery);
                exit;
            }
        } ?>


    </div>
    <div>
        <p class="animate-charcter">Which file type you want to upload?</p>
        <br>
        <a class="a1" href="fileup.php">txt/zip</a>
        <br>
        <br>
        <a class="a1" href="imgup.php">img</a>
    </div>
</body>

</html>
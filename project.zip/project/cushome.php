<?php
include 'filedownprocess.php'; ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Document</title>
    <link rel="stylesheet" href="cuscss.css">
</head>

<body>
<a class="a" href="cuscgpass.php">My Profile</a>
    <div class="main-header">
        <div class="container">
        <h1 class="h1">Customer Homepage</h1>
        </div>
    </div>
    
    
    <table class="styled-table">
        <thead>
            <th>ID</th>
            <th>Filename</th>
            <th>size (in mb)</th>
            <th>Description</th>
            <th>Downloads</th>
            <th>Price</th>
            <th>Email</th>
            <th>Action</th>
        </thead>
        <tbody>
            <?php foreach ($files as $file) : ?>
                <tr class="active-row">
                    <td><?php echo $file['id']; ?></td>
                    <td><?php echo $file['name']; ?></td>
                    <td><?php echo floor($file['size'] / 1000) . ' KB'; ?></td>
                    <td><?php echo $file['Description']; ?></td>
                    <td><?php echo $file['downloads']; ?></td>
                    <td><?php echo $file['Price']; ?></td>
                    <td><?php echo $file['Email']; ?></td>
                    <td><a href="payment.php?file_id=<?php echo $file['id'] ?>">Download</a></td>
                </tr>
            <?php endforeach; ?>

        </tbody>
    </table>
    <h1>Images</h1>
    <?php
    include 'imgupprocess.php';
    $email = $_SESSION['email'];

    $result = $con->query("SELECT image, Price FROM uploads ORDER BY id DESC");
    ?>

    <?php if ($result->num_rows > 0) { ?>
        <div class="wrapper">
            <?php while ($row = $result->fetch_assoc()) { ?>
                <img class="box" width="400" height="300" src="data:image/jpg;charset=utf8;base64,<?php echo base64_encode($row['image']); ?>" />
                <?php echo $row['Price']; ?>
            <?php } ?>
        </div>
    <?php } else { ?>
        <p>Image(s) not found...</p>
    <?php } ?>
</body>

</html>